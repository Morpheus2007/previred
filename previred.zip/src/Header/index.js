import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import logo from "../img/logo.png";
import MenuHeader from "../Menu/components/MenuHeader";
import MenuSideBar from "../Menu/components/MenuSideBar";
import { get } from "../utils/functions/localStorage";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
  logo: {
    width: "150px",
    height: "auto",
  },
}));

const Header = () => {
  const classes = useStyles();

  let token = get("token");

  if (token === null) {
    window.location.href = "/";
  } else {
    return (
      <AppBar position="static" color="default">
        <Toolbar>
          <img src={logo} className={classes.logo} />
          <Typography variant="h6" className={classes.title}></Typography>
          <MenuHeader />
        </Toolbar>
      </AppBar>
    );
  }
};

export default Header;

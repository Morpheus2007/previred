import { GET_TOKEN, GET_TOKEN_EXITO, GET_TOKEN_ERROR } from "../types";
import { parseJwt, rutWithouthFormat } from "../../utils/functions/utility";
import { save } from "../../utils/functions/localStorage";

let urlEmpleadosApi = process.env.REACT_APP_API_EMPLEADOS;

export function getTokenAction(rut, password) {
  let options = {
    method: "POST",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
    },
    body: JSON.stringify({
      rut: parseInt(rutWithouthFormat(rut)),
      password: password,
    }),
  };

  return async (dispatch) => {
    dispatch(getToken());
    try {
      let response = await fetch(urlEmpleadosApi + "/token", options);
      if (response.status === 200) {
        let data = await response.json();
        let decodeToken = parseJwt(data.accessToken);
        save(
          "usuario",
          decodeToken.employee.name + " " + decodeToken.employee.surname
        );
        save("isAdm", true);
        //save("isAdm", decodeToken.employee.isAdm);
        save("token", data.accessToken);
        dispatch(getTokenExito(data));
        window.location.href = "/empleados";
      } else {
        dispatch(getTokenError());
      }
    } catch (error) {
      dispatch(getTokenError(error));
    }
  };
}

export const getToken = () => ({
  type: GET_TOKEN,
});

export const getTokenExito = (token) => ({
  type: GET_TOKEN_EXITO,
  payload: token,
});

export const getTokenError = (error) => ({
  type: GET_TOKEN_ERROR,
  payload: error,
});

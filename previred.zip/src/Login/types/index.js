export const GET_TOKEN = "GET_TOKEN";
export const GET_TOKEN_EXITO = "GET_TOKEN_EXITO";
export const GET_TOKEN_ERROR = "GET_TOKEN_ERRORS";

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import logo from "../../img/logo.png";
import { getTokenAction } from "../actions";
import { format, validaRut } from "../../utils/functions/utility";
import Swal from "sweetalert2";

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

const Login = () => {
  const dispatch = useDispatch();
  const [rut, setRut] = useState("");
  const [password, setPassword] = useState("");

  const handleChangeRut = (e) => {
    let rutFormated = format(e.target.value);
    setRut(rutFormated);
  };

  const handleChangePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleClickIngresar = (e) => {
    if (!validaRut(rut.replace(/\./g, "")) && rut.length > 0) {
      Swal.fire({
        title: "Previred",
        html: "<p>Rut no es correcto</p>",
        confirmButtonColor: "#3085d6",
        allowOutsideClick: false,
        confirmButtonText: "Aceptar",
        allowOutsideClick: false,
        heightAuto: false,
        type: "warning",
      });
    } else {
      if (
        password === "" ||
        password === undefined ||
        password === null ||
        rut === "" ||
        rut === undefined ||
        rut === null
      ) {
        Swal.fire({
          title: "Previred",
          html: "<p>Debe ingresar Rut y  Password</p>",
          confirmButtonColor: "#3085d6",
          allowOutsideClick: false,
          confirmButtonText: "Aceptar",
          allowOutsideClick: false,
          heightAuto: false,
          type: "warning",
        });
      } else {
        dispatch(getTokenAction(rut, password));
      }
    }
  };

  const classes = useStyles();

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <img src={logo} />

        <form className={classes.form} autoComplete="off">
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="rutLogin"
            label="Rut"
            name="rutLogin"
            type="text"
            onChange={(e) => handleChangeRut(e)}
            value={rut}
            inputProps={{ maxLength: 12 }}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="passwordLogin"
            label="Password"
            type="password"
            id="passwordLogin"
            onChange={(e) => handleChangePassword(e)}
            value={password}
          />

          <Button
            type="button"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={() => handleClickIngresar()}
          >
            Ingresar
          </Button>
        </form>
      </div>
    </Container>
  );
};

export default Login;

import { GET_TOKEN, GET_TOKEN_EXITO, GET_TOKEN_ERROR } from "../types";

const initialState = {
  token: {},
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_TOKEN:
      return {
        ...state,
        error: false,
      };
    case GET_TOKEN_EXITO:
      return {
        ...state,
        token: action.payload,
        error: false,
      };
    case GET_TOKEN_ERROR:
      return {
        ...state,
        token: {},
        error: true,
      };
    default:
      return state;
  }
}

import { get } from "../../utils/functions/localStorage";
import {
  GETALL_EMPLEADOS,
  GETALL_EMPLEADOS_ERROR,
  GETALL_EMPLEADOS_EXITO,
  GET_DEPTOS,
  GET_DEPTOS_EXITO,
  GET_DEPTOS_ERROR,
  GETALL_EMPLEADO_EXITO,
} from "../types";
import Swal from "sweetalert2";

import { format } from "../../utils/functions/utility";

let urlEmpleadosApi = process.env.REACT_APP_API_EMPLEADOS;

export function getAllEmployeesAction() {
  let options = {
    method: "GET",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  };

  return async (dispatch) => {
    dispatch(getEmployees());
    try {
      let response = await fetch(urlEmpleadosApi + "/employees", options);
      if (response.status === 200) {
        let data = await response.json();
        dispatch(getEmployeesExito(data));
      } else {
        dispatch(getEmployeesError());
      }
    } catch (error) {
      dispatch(getEmployeesError(error));
    }
  };
}

export const getEmployees = () => ({
  type: GETALL_EMPLEADOS,
});

export const getEmployeesExito = (empleados) => ({
  type: GETALL_EMPLEADOS_EXITO,
  payload: empleados,
});

export const getEmployeesError = (error) => ({
  type: GETALL_EMPLEADOS_ERROR,
  payload: error,
});

export function getAllDeptosAction() {
  let options = {
    method: "GET",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  };

  return async (dispatch) => {
    dispatch(getDeptos());
    try {
      let response = await fetch(urlEmpleadosApi + "/departments", options);
      if (response.status === 200) {
        let data = await response.json();
        dispatch(getDeptosExito(data));
      } else {
        dispatch(getDeptosError());
      }
    } catch (error) {
      dispatch(getDeptosError(error));
    }
  };
}

export const getDeptos = () => ({
  type: GET_DEPTOS,
});

export const getDeptosExito = (departamentos) => ({
  type: GET_DEPTOS_EXITO,
  payload: departamentos,
});

export const getDeptosError = (error) => ({
  type: GET_DEPTOS_ERROR,
  payload: error,
});

export function deleteEmployeesByIdAction(idEmployee) {
  let options = {
    method: "DELETE",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  };
  return async (dispatch) => {
    dispatch(getEmployees());
    try {
      let response = await fetch(
        urlEmpleadosApi + `/employees/${idEmployee}`,
        options
      );
      if (response.status === 204) {
        dispatch(getAllEmployeesAction());
      } else {
        dispatch(getEmployeesError());
      }
    } catch (error) {
      dispatch(getEmployeesError(error));
    }
  };
}

export function createEmployeesByIdAction(empleado) {
  let options = {
    method: "POST",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
    body: JSON.stringify(empleado),
  };

  return async (dispatch) => {
    dispatch(getEmployees());
    try {
      let response = await fetch(urlEmpleadosApi + `/employees`, options);
      if (response.status === 204) {
        Swal.fire({
          title: "Previred",
          html: "<p>Empleado Creado</p>",
          confirmButtonColor: "#3085d6",
          allowOutsideClick: false,
          confirmButtonText: "Aceptar",
          allowOutsideClick: false,
          heightAuto: false,
          type: "success",
        });
        dispatch(getAllEmployeesAction());
      } else {
      }
    } catch (error) {}
  };
}

export function setDialogEmployeeSelectedAction(empleado) {
  return async (dispatch) => {
    document.getElementById("idEmployee").value = empleado.idEmployee;

    document.getElementById("rutEditar").value = format(
      empleado.rut + "" + empleado.dv
    );
    document.getElementById("nombreEditar").value = empleado.name;
    document.getElementById("apellidoEditar").value = empleado.surname;
    document.getElementById("emailEditar").value = empleado.email;
    document.getElementById("deptoEditar").value =
      empleado.department.description;
  };
}

export const getEmployeeExito = (empleado) => ({
  type: GETALL_EMPLEADO_EXITO,
  payload: empleado,
});

export function updateEmployeesByIdAction(empleado, idEmployee) {
  let options = {
    method: "PUT",
    mode: "cors",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
    body: JSON.stringify(empleado),
  };

  return async (dispatch) => {
    dispatch(getEmployees());
    try {
      let response = await fetch(
        urlEmpleadosApi + `/employees/${idEmployee}`,
        options
      );
      if (response.status === 202) {
        Swal.fire({
          title: "Previred",
          html: "<p>Empleado Modificado</p>",
          confirmButtonColor: "#3085d6",
          allowOutsideClick: false,
          confirmButtonText: "Aceptar",
          allowOutsideClick: false,
          heightAuto: false,
          type: "success",
        });
        dispatch(getAllEmployeesAction());
        document.getElementById("idEmployee").value = "";

        document.getElementById("rutEditar").value = "";
        document.getElementById("nombreEditar").value = "";
        document.getElementById("apellidoEditar").value = "";
        document.getElementById("emailEditar").value = "";
        document.getElementById("deptoEditar").value = "";
      } else {
        dispatch(getEmployeesError());
      }
    } catch (error) {
      dispatch(getEmployeesError(error));
    }
  };
}

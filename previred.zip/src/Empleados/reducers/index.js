import {
  GETALL_EMPLEADOS,
  GETALL_EMPLEADOS_EXITO,
  GETALL_EMPLEADOS_ERROR,
  GETALL_EMPLEADO,
  GETALL_EMPLEADO_EXITO,
  GETALL_EMPLEADO_ERROR,
  GET_DEPTOS,
  GET_DEPTOS_EXITO,
  GET_DEPTOS_ERROR,
} from "../types";

const initialState = {
  empleados: [],
  departamentos: [],
  empleado: {},
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GETALL_EMPLEADOS:
      return {
        ...state,
        error: false,
      };
    case GETALL_EMPLEADOS_EXITO:
      return {
        ...state,
        empleados: action.payload,
        error: false,
      };
    case GETALL_EMPLEADOS_ERROR:
      return {
        ...state,
        empleados: [],
        error: true,
      };
    case GETALL_EMPLEADO:
      return {
        ...state,
        error: false,
      };
    case GETALL_EMPLEADO_EXITO:
      return {
        ...state,
        empleado: action.payload,
        error: false,
      };
    case GETALL_EMPLEADO_ERROR:
      return {
        ...state,
        empleado: [],
        error: true,
      };
    case GET_DEPTOS:
      return {
        ...state,
        error: false,
      };
    case GET_DEPTOS_EXITO:
      return {
        ...state,
        departamentos: action.payload,
        error: false,
      };
    case GET_DEPTOS_ERROR:
      return {
        ...state,
        departamentos: [],
        error: true,
      };
    default:
      return state;
  }
}

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Grid from "@material-ui/core/Grid";
import Autocomplete from "@material-ui/lab/Autocomplete";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { getAllDeptosAction, createEmployeesByIdAction } from "../actions";
import { format, validaRut } from "../../utils/functions/utility";

import Swal from "sweetalert2";

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const CreateEmpleado = () => {
  const classes = useStyles();

  const dispatch = useDispatch();
  const [open, setOpen] = React.useState(false);
  const [rut, setRut] = useState("");
  const [nombre, setNombre] = useState("");
  const [apellido, setApellido] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [departamento, setDepartamento] = useState("");
  const [administrador, setAdministrador] = useState(false);

  useEffect(() => {
    const cargarDeptos = () => dispatch(getAllDeptosAction());
    cargarDeptos();
  }, []);

  const deptos = useSelector((state) => state.empleados.departamentos);

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleChangeRut = (e) => {
    let rutFormated = format(e.target.value);
    setRut(rutFormated);
  };

  const handleChangeNombre = (e) => {
    setNombre(e.target.value);
  };
  const handleChangeApellido = (e) => {
    setApellido(e.target.value);
  };
  const handleChangePassword = (e) => {
    setPassword(e.target.value);
  };
  const handleChangeEmail = (e) => {
    setEmail(e.target.value);
  };

  const handleChangeDepto = (values) => {
    setDepartamento({ idDept: values.idDept, description: values.description });
  };

  const handleChangeCheckAdm = (e) => {
    setAdministrador(e.target.checked);
  };

  const handleClickCrear = () => {
    let rutSplit = rut.replace(/\./g, "").split("-");

    let empleado = {
      name: nombre,
      surname: apellido,
      email: email,
      rut: parseInt(rutSplit[0]),
      dv: rutSplit[1],
      password: password,
      department: departamento,
      isAdm: administrador,
    };

    {
      if (
        rut == "" ||
        rut == null ||
        nombre == "" ||
        nombre == null ||
        apellido == "" ||
        apellido == null ||
        email == "" ||
        email == null ||
        password === "" ||
        password === null ||
        departamento == null ||
        departamento == undefined ||
        departamento == ""
      ) {
        Swal.fire({
          title: "Previred",
          html: "<p>Debe ingresar los campos indicados obligatorios (*)</p>",
          confirmButtonColor: "#3085d6",
          allowOutsideClick: false,
          confirmButtonText: "Aceptar",
          allowOutsideClick: false,
          heightAuto: false,
          type: "warning",
        });
      } else {
        dispatch(createEmployeesByIdAction(empleado));
      }
    }
  };

  return (
    <div style={{ height: 640, width: "100%", marginTop: "40px" }}>
      <Typography
        variant="h5"
        id="tableTitle"
        component="div"
        style={{
          textAlign: "center",
        }}
      >
        Crear Empleados
      </Typography>
      <form className={classes.form} noValidate>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              id="RutCrear"
              name="RutCrear"
              variant="outlined"
              required
              fullWidth
              label="Rut"
              onChange={(e) => handleChangeRut(e)}
              value={rut}
              inputProps={{ maxLength: 12 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              id="nombreCrear"
              name="nombreCrear"
              variant="outlined"
              required
              fullWidth
              label="Nombre"
              onChange={(e) => handleChangeNombre(e)}
              value={nombre}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              id="ApellidoCrear"
              name="apellidoCrear"
              variant="outlined"
              required
              fullWidth
              label="Apellido"
              onChange={(e) => handleChangeApellido(e)}
              value={apellido}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              variant="outlined"
              fullWidth
              required
              id="email"
              label="Email Address"
              name="email"
              onChange={(e) => handleChangeEmail(e)}
              value={email}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              variant="outlined"
              name="password"
              label="Password"
              type="password"
              id="password"
              required
              fullWidth
              onChange={(e) => handleChangePassword(e)}
              value={password}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <Autocomplete
              id="deptoCreate"
              name="deptoCreate"
              fullWidth
              required
              options={deptos}
              getOptionLabel={(option) => option.description}
              disableClearable={true}
              contentEditable={false}
              onChange={handleChangeDepto}
              noOptionsText="No se encontraron Deptos"
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Departamento"
                  variant="outlined"
                />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Checkbox
                  id="esAdministadorCreate"
                  name="esAdministadorCreate"
                  color="primary"
                  onChange={(e) => handleChangeCheckAdm(e)}
                />
              }
              label="Administrador"
            />
          </Grid>
        </Grid>
        <Button
          type="button"
          fullWidth
          variant="contained"
          color="primary"
          className={classes.submit}
          onClick={() => handleClickCrear()}
        >
          Crear
        </Button>
      </form>
    </div>
  );
};
export default CreateEmpleado;

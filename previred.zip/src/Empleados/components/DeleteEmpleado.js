import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Container, Typography, Button } from "@material-ui/core";
import {
  deleteEmployeesByIdAction,
  getAllEmployeesAction,
} from "../actions/index";
import { DataGrid } from "@material-ui/data-grid";
import { format } from "../../utils/functions/utility";
import store from "../../store";
import Swal from "sweetalert2";

const handleClickActionGrid = (idEmployee) => {
  Swal.fire({
    title: "¿Está seguro de eliminar al empleado?",

    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    allowOutsideClick: false,
    cancelButtonColor: "#d9534f",
    confirmButtonText: "Sí, estoy seguro",
    cancelButtonText: "Cancelar",
    reverseButtons: true,
    allowOutsideClick: false,
    heightAuto: false,
  }).then((response) => {
    if (!response.hasOwnProperty("dismiss")) {
      store.dispatch(deleteEmployeesByIdAction(idEmployee));
    }
  });
};

const columns = [
  { field: "id", headerName: "Id", width: 150 },
  { field: "rut", headerName: "Rut", width: 150 },
  { field: "empleado", headerName: "Empleado", width: 180 },
  { field: "email", headerName: " Email", width: 130 },
  { field: "depto", headerName: "Depto", width: 160 },
  {
    field: "action",
    headerName: "Actions",
    width: 150,
    renderCell: (params) => (
      <Button
        variant="contained"
        color="secondary"
        size="small"
        style={{ marginLeft: 16 }}
        onClick={() => handleClickActionGrid(params.row.id)}
      >
        Eliminar
      </Button>
    ),
  },
];

const DeleteEmpleado = (props) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const cargarEmpleados = () => dispatch(getAllEmployeesAction());
    cargarEmpleados();
  }, []);

  const empleados = useSelector((state) => state.empleados.empleados);

  const rows = empleados.map(function (a, i) {
    return {
      id: a.idEmployee,
      rut: format(a.rut + a.dv),
      empleado: a.name + " " + a.surname,
      email: a.email,
      depto: empleados[i].department.description,
      action: "",
    };
  });

  return (
    <div style={{ height: 640, width: "100%", marginTop: "40px" }}>
      <Typography
        variant="h5"
        id="tableTitle"
        component="div"
        style={{
          textAlign: "center",
        }}
      >
        Eliminar Empleados
      </Typography>

      <DataGrid rows={rows} columns={columns} />
    </div>
  );
};

export default DeleteEmpleado;

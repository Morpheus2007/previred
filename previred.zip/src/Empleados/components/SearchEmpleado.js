import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Container, Typography, Button } from "@material-ui/core";
import { getAllEmployeesAction } from "../actions/index";
import { DataGrid } from "@material-ui/data-grid";
import { format } from "../../utils/functions/utility";

const columns = [
  { field: "id", headerName: "Id", width: 150 },
  { field: "rut", headerName: "Rut", width: 150 },
  { field: "empleado", headerName: "Empleado", width: 180 },
  { field: "email", headerName: " Email", width: 130 },
  { field: "depto", headerName: "Depto", width: 160 },
];

const SearchEmpleado = (props) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const cargarEmpleados = () => dispatch(getAllEmployeesAction());
    cargarEmpleados();
  }, []);

  const empleados = useSelector((state) => state.empleados.empleados);

  const rows = empleados.map(function (a, i) {
    return {
      id: a.idEmployee,
      rut: format(a.rut + a.dv),
      empleado: a.name + " " + a.surname,
      email: a.email,
      depto: empleados[i].department.description,
    };
  });

  return (
    <div style={{ height: 640, width: "100%", marginTop: "40px" }}>
      <Typography
        variant="h5"
        id="tableTitle"
        component="div"
        style={{
          textAlign: "center",
        }}
      >
        Consulta Empleados
      </Typography>

      <DataGrid rows={rows} columns={columns} />
    </div>
  );
};

export default SearchEmpleado;

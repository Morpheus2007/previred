import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Container, Typography, Button } from "@material-ui/core";
import {
  getAllEmployeesAction,
  setDialogEmployeeSelectedAction,
} from "../actions/index";
import { DataGrid } from "@material-ui/data-grid";
import { format } from "../../utils/functions/utility";
import store from "../../store";
import UpdateDialog from "../../utils/forms/Dialog";

const columns = [
  { field: "id", headerName: "Id", width: 150 },
  { field: "rut", headerName: "Rut", width: 150 },
  { field: "empleado", headerName: "Empleado", width: 180 },
  { field: "email", headerName: " Email", width: 130 },
  { field: "depto", headerName: "Depto", width: 160 },
  { field: "objempleado", headerName: "objEmpleado", hide: true },
  {
    field: "action",
    headerName: "Actions",
    width: 150,
    renderCell: (params) => (
      <Button
        variant="contained"
        color="primary"
        size="small"
        style={{ marginLeft: 16 }}
        onClick={() => {
          store.dispatch(
            setDialogEmployeeSelectedAction(params.row.objempleado)
          );
        }}
      >
        Modificar
      </Button>
    ),
  },
];

const UpdateEmpleado = (props) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const cargarEmpleados = () => dispatch(getAllEmployeesAction());
    cargarEmpleados();
  }, []);

  const empleados = useSelector((state) => state.empleados.empleados);

  const rows = empleados.map(function (a, i) {
    return {
      id: a.idEmployee,
      rut: format(a.rut + a.dv),
      empleado: a.name + " " + a.surname,
      email: a.email,
      depto: empleados[i].department.description,
      action: "",
      objempleado: empleados[i],
    };
  });

  return (
    <div style={{ height: 400, width: "105%", marginTop: "40px" }}>
      <Typography
        variant="h5"
        id="tableTitle"
        component="div"
        style={{
          textAlign: "center",
        }}
      >
        Modificar Empleados
      </Typography>

      <DataGrid rows={rows} columns={columns} />
      <UpdateDialog />
    </div>
  );
};

export default UpdateEmpleado;

export const menuSideBar = [
  {
    link: "Consulta Empleados",
    isAdm: "false",
  },
  {
    link: "Crear Empleado",
    isAdm: "true",
  },
  {
    link: "Modificar Empleado",
    isAdm: "false",
  },
  {
    link: "Eliminar Empleado",
    isAdm: "true",
  },
];

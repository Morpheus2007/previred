import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import store from "./store";
import { Provider } from "react-redux";
import Login from "./Login/components";
import MenuContent from "./Menu/components/MenuContent";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Switch>
          <Route exact path="/" render={(props) => <Login {...props} />} />
        </Switch>
        <Switch>
          <Route
            exact
            path="/empleados"
            render={(props) => <MenuContent {...props} />}
          />
        </Switch>
      </Router>
    </Provider>
  );
}

export default App;

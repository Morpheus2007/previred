import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import logo from "../../img/logo.png";
import Header from "../../Header";
import MenuSideBar from "./MenuSideBar";
import { get } from "../../utils/functions/localStorage";
import MenuHeader from "./MenuHeader";
import { Container } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
  logo: {
    width: "150px",
    height: "auto",
  },
}));

const MenuContent = () => {
  let token = get("token");

  if (token === null) {
    window.location.href = "/";
  } else {
    return (
      <div>
        <Header />
        <MenuSideBar />
      </div>
    );
  }
};

export default MenuContent;

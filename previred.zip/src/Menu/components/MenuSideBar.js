import React, { useState } from "react";
import CssBaseline from "@material-ui/core/CssBaseline";
import Divider from "@material-ui/core/Divider";
import Drawer from "@material-ui/core/Drawer";
import Hidden from "@material-ui/core/Hidden";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Link from "@material-ui/core/Link";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import { menuSideBar } from "../../constants";
import { Button, Container } from "@material-ui/core";
import { get } from "../../utils/functions/localStorage";
import SearchEmpleado from "../../Empleados/components/SearchEmpleado";
import CreateEmpleado from "../../Empleados/components/CreateEmpleado";
import UpdateEmpleado from "../../Empleados/components/UpdateEmpleado";
import DeleteEmpleado from "../../Empleados/components/DeleteEmpleado";

const drawerWidth = 210;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  drawer: {
    [theme.breakpoints.up("sm")]: {
      width: drawerWidth,
      flexShrink: 0,
      zIndex: 0,
    },
  },
  appBar: {
    [theme.breakpoints.up("sm")]: {
      width: `calc(100% - ${drawerWidth}px)`,
      marginLeft: drawerWidth,
    },
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("sm")]: {
      display: "none",
    },
  },
  toolbar: theme.mixins.toolbar,
  drawerPaper: {
    width: drawerWidth,
    top: 66,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}));

const MenuSideBar = (props) => {
  const { window } = props;
  const classes = useStyles();
  let isAdm = get("isAdm");

  const [menuItem, setMenuItem] = useState("");

  const handleClickMenuItem = (link) => {
    setMenuItem(link);
  };

  const drawer = (
    <div>
      <div className={classes.toolbar}>
        <List>
          {isAdm === "true"
            ? menuSideBar.map((menu, index) => (
                <Button
                  component="button"
                  style={{ fontWeight: "bolder" }}
                  key={index}
                  onClick={() => handleClickMenuItem(menu.link)}
                >
                  {menu.link}
                </Button>
              ))
            : menuSideBar
                .filter((x) => x.isAdm === "false")
                .map((menu, index) => (
                  <Button
                    component="button"
                    style={{ fontWeight: "bolder" }}
                    key={index}
                    onClick={() => handleClickMenuItem(menu.link)}
                  >
                    {menu.link}
                  </Button>
                ))}
        </List>
      </div>
    </div>
  );

  return (
    <div className={classes.root}>
      <CssBaseline />
      <nav className={classes.drawer} aria-label="mailbox folders">
        <Drawer
          classes={{
            paper: classes.drawerPaper,
          }}
          variant="permanent"
          open
        >
          {drawer}
        </Drawer>
      </nav>
      <Container maxWidth="md">
        {menuItem === "Consulta Empleados" ? <SearchEmpleado /> : ""}
        {menuItem === "Crear Empleado" ? <CreateEmpleado /> : ""}
        {menuItem === "Modificar Empleado" ? <UpdateEmpleado /> : ""}
        {menuItem === "Eliminar Empleado" ? <DeleteEmpleado /> : ""}
      </Container>
    </div>
  );
};

export default MenuSideBar;

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Grid from "@material-ui/core/Grid";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { makeStyles } from "@material-ui/core/styles";
import {
  getAllDeptosAction,
  updateEmployeesByIdAction,
  getEmployeeExito,
} from "../../../Empleados/actions";
import { format, validaRut } from "../../functions/utility";
import { InputLabel } from "@material-ui/core";
import Swal from "sweetalert2";

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const UpdateDialog = (props) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [rut, setRut] = useState("");
  const [nombre, setNombre] = useState("");
  const [apellido, setApellido] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [departamento, setDepartamento] = useState("");
  const [administrador, setAdministrador] = useState(false);

  useEffect(() => {
    const cargarDeptos = () => dispatch(getAllDeptosAction());
    cargarDeptos();

    const vaciarEmpleado = () => dispatch(getEmployeeExito({}));
  }, []);

  const deptos = useSelector((state) => state.empleados.departamentos);
  const empleado = useSelector((state) => state.empleados.empleado);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChangeRut = (e) => {
    let rutFormated = format(e.target.value);
    setRut(rutFormated);
  };

  const handleChangeNombre = (e) => {
    setNombre(e.target.value);
  };
  const handleChangeApellido = (e) => {
    setApellido(e.target.value);
  };
  const handleChangePassword = (e) => {
    setPassword(e.target.value);
  };
  const handleChangeEmail = (e) => {
    setEmail(e.target.value);
  };

  const handleChangeDepto = (values) => {
    setDepartamento({ idDept: values.idDept, description: values.description });
  };

  const handleChangeCheckAdm = (e) => {
    setAdministrador(e.target.checked);
  };

  const handleClickModificar = () => {
    let rutSplit = document
      .getElementById("rutEditar")
      .value.replace(/\./g, "")
      .split("-");

    let idEmployee = document.getElementById("idEmployee").value;
    let empleadoUpdate = {
      name: document.getElementById("nombreEditar").value,
      surname: document.getElementById("apellidoEditar").value,
      email: document.getElementById("emailEditar").value,
      rut: parseInt(rutSplit[0]),
      dv: rutSplit[1],
      password: password,
      department: deptos.find(
        (x) => x.description == document.getElementById("deptoEditar").value
      ),
      isAdm: administrador,
    };

    if (
      document.getElementById("rutEditar").value === "" ||
      document.getElementById("idEmployee").value == "" ||
      document.getElementById("nombreEditar").value == "" ||
      document.getElementById("apellidoEditar").value == "" ||
      document.getElementById("emailEditar").value == "" ||
      document.getElementById("deptoEditar").value == ""
    ) {
      Swal.fire({
        title: "Previred",
        html: "<p>Debe ingresar los campos indicados obligatorios (*)</p>",
        confirmButtonColor: "#3085d6",
        allowOutsideClick: false,
        confirmButtonText: "Aceptar",
        allowOutsideClick: false,
        heightAuto: false,
        type: "warning",
      });
    } else {
      dispatch(updateEmployeesByIdAction(empleadoUpdate, idEmployee));
    }
  };

  return (
    <div>
      <form className={classes.form} noValidate>
        <Grid container spacing={2}>
          <input id="idEmployee" name="idEmployee" type="hidden"></input>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Rut</InputLabel>
            <TextField
              id="rutEditar"
              name="rutEditar"
              variant="outlined"
              required
              fullWidth
              onChange={(e) => handleChangeRut(e)}
              inputProps={{ maxLength: 12 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Nombre</InputLabel>
            <TextField
              id="nombreEditar"
              name="nombreEditar"
              variant="outlined"
              required
              fullWidth
              onChange={(e) => handleChangeNombre(e)}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Apellido</InputLabel>
            <TextField
              id="apellidoEditar"
              name="apellidoEditar"
              variant="outlined"
              required
              fullWidth
              onChange={(e) => handleChangeApellido(e)}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Email</InputLabel>
            <TextField
              variant="outlined"
              fullWidth
              required
              id="emailEditar"
              name="emailEditar"
              onChange={(e) => handleChangeEmail(e)}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Password</InputLabel>
            <TextField
              variant="outlined"
              name="passwordEditar"
              type="password"
              id="passwordEditar"
              required
              fullWidth
              onChange={(e) => handleChangePassword(e)}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InputLabel required>Departamento</InputLabel>
            <Autocomplete
              id="deptoEditar"
              name="deptoEditar"
              fullWidth
              required
              options={deptos}
              getOptionLabel={(option) => option.description}
              disableClearable={true}
              contentEditable={false}
              onChange={handleChangeDepto}
              noOptionsText="No se encontraron Deptos"
              renderInput={(params) => (
                <TextField {...params} variant="outlined" />
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Checkbox
                  id="esAdministadorEditar"
                  name="esAdministadorEditar"
                  color="primary"
                  onChange={(e) => handleChangeCheckAdm(e)}
                />
              }
              label="Administrador"
            />
          </Grid>
        </Grid>
        <Button
          type="button"
          fullWidth
          variant="contained"
          color="primary"
          className={classes.submit}
          onClick={() => handleClickModificar()}
        >
          Modificar
        </Button>
      </form>
    </div>
  );
};
export default UpdateDialog;

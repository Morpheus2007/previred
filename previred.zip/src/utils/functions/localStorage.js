export const save = (key, value) => {
    localStorage.setItem(key, value);
  };
  
  export const get = key => {
    return localStorage.getItem(key);
  };
  
  export const checkExist = key => {
    return localStorage.getItem(key) !== null ? true : false;
  };
  
  export const clear = key => {
    localStorage.removeItem(key);
  };
  
  export const clearAll = () => {
    localStorage.clear();
  };
  
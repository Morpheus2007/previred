import { combineReducers } from "redux";
import empleados from "../Empleados/reducers";
import token from "../Login/reducers";

export default combineReducers({
  empleados,
  token,
});

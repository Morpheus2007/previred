## Available Scripts

Para ejecutar la aplicación se debe levantar el api Java example.jar.
a traves del comando

### java -jar example-api-1.0.0.jar

Luego iniciar desde el directorio del aplicativo el siguiente script. Por defecto para construir el aplicativo se utilizo el IDE VS Code.

Se debe ejecutar el siguiente comando para instalar los paquetes asociados al proyecto.

### `npm install`

Para luego ejecutar el comando que da inicio al aplicativo

### `npm start`

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
